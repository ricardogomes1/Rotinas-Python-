#!/bin/sh
phpize
./configure --with-ming=/path/to/ming
make
make install
