/* libswf.h - global typedefs, etc. */

#ifndef LIBSWF_H_INCLUDED
#define LIBSWF_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>

typedef unsigned char byte;


#endif /* LIBSWF_H_INCLUDED */
